import sqlite3

connection = sqlite3.connect('data.db')
cursor = connection.cursor()

create_tbl_qry = """
--sql
CREATE TABLE IF NOT EXISTS users
(
    id INTEGER PRIMARY KEY,
    email text,
    password text,
    firstname text,
    lastname text,    
    dob text, -- this could/should be a date type, leaving as text for now
    gender
)
--endsql
"""

cursor.execute(create_tbl_qry)
connection.commit()
connection.close()
