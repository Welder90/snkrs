import sqlite3

connection = sqlite3.connect('data.db')
cursor = connection.cursor()

users = [
    ''' `users` format:
    (unique_id(pk), email, password, firstname, lastname, dob, gender)
    '''
    (1, 'dunksfan85@gmail.com', 'Passw0rd_1', 'Michael', 'J', '31/07/1985', 'male'),
    (2, 'sneakzkobe79@gmail.com', 'P4ssw0rd_123', 'Kobe', 'Bryant', '23/02/1979', 'male')
]

insert_qry = "INSERT INTO users VALUES (?, ?, ?)"
cursor.execute(insert_qry, users)

connection.commit()
connection.close()


