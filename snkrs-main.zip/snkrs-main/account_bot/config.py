import os

CHROMEDRIVER_PTH = os.path.join(os.path.dirname(__file__), '../assets/chromedriver_v87.exe')

# check config variables
try:
    assert os.path.exists(CHROMEDRIVER_PTH)
except FileNotFoundError:
    print(f'Driver {CHROMEDRIVER_PTH} does not exist!')