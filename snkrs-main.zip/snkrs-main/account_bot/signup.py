import os
import sys

from config import CHROMEDRIVER_PTH
from selenium import webdriver

import datetime
import time
import argparse


URL = 'https://nike.com/uk/launch'
SLEEP_TIME_SECS = 0.5

class SignUp():
    def __init__(self, fname, lname, email, pwd, dob, gender):
        self.url = URL
        self.first_name = fname
        self.last_name = lname
        self.email = email
        self.password = pwd
        self.date_of_birth = dob
        self.gender = gender

        # data validation
        try:
            datetime.datetime.strptime(self.date_of_birth, 'd/%m/%Y')
        except ValueError:
            print("ValueError: Date of birth provided needs to be of the format -- dd/mm/yyyy.")


    def open_browser(self):
        if os.path.exists(CHROMEDRIVER_PTH):
            self.browser = webdriver.Chrome(executable_path=fr"{CHROMEDRIVER_PTH}")
        else:
            self.browser = webdriver.Chrome('ChromeDriver')

        # set chrome driver settings to make bot less recognisable
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # in addition this will prevent menu from collapsing avoiding additional steps to 
        # which needs to be uncollapsed to navigate to login link
        chrome_options.add_argument("window-size=1400,600")

        self.browser.set_window_size(1920, 1080)
        self.browser.get(self.url)

    def goto_login_page(self):
        # so far xpath seems to be only working approach, this could however break easily
        self.browser.find_element_by_xpath(
            '/html/body/div[2]/div/div/div[1]/div/header/div[1]/section/div/ul/li[1]/button').click()
        
        time.sleep(SLEEP_TIME_SECS)

    def goto_signup_page(self):
        '''
        Go to sign up ("Join Us.") page. NB: 
        Current approach is slow and convoluted -- needs revision
        '''
        a_elems = self.browser.find_elements_by_tag_name("a")
        for name in a_elems:
            if (name.get_attribute("href")) is not None and \
                "javascript:void" in name.get_attribute("href") and \
                name.get_attribute('innerHTML')=='Join Us.':            
                    name.click()

        time.sleep(SLEEP_TIME_SECS)

    def signup(self):

        self.open_browser()
        self.goto_login_page()
        self.goto_signup_page()

        ''' Inputs required information provided to class to signup form '''
        # 1. Enter email address
        self.browser\
            .find_element_by_css_selector("input[placeholder='Email address']")\
            .send_keys(self.email)        

        time.sleep(SLEEP_TIME_SECS)

        # 2. Enter password
        # - NB: password requirements are min 8 characters, 1 uppercase letter, 1 lowercase letter, 1 number
        self.browser\
            .find_element_by_css_selector("input[placeholder='Password']")\
            .send_keys(self.password)

        time.sleep(SLEEP_TIME_SECS)

        # 3. Enter first name
        self.browser\
            .find_element_by_css_selector("input[placeholder='First Name']")\
            .send_keys(self.first_name)

        time.sleep(SLEEP_TIME_SECS)

        # 4. Enter last name
        self.browser\
            .find_element_by_css_selector("input[placeholder='Last Name']")\
            .send_keys(self.last_name)

        time.sleep(SLEEP_TIME_SECS)

        # 5. Enter date of birth (must be dd/mm/yyyy)
        self.browser\
            .find_element_by_css_selector("input[placeholder='Date of Birth']")\
            .send_keys(self.date_of_birth)

        time.sleep(SLEEP_TIME_SECS)

        # 6. Select gender (male/female)
        gender_str = 'Male' if self.gender.lower() == 'male' else 'Female'
        self.browser\
            .find_element_by_xpath(fr"//span[text() = '{gender_str}']")\
            .click()

        time.sleep(SLEEP_TIME_SECS)

        # 7. Sign up
        self.browser\
            .find_element_by_css_selector("input[value='JOIN US']")\
            .click()



if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Sign up new user to Nike Launch site.')

    parser.add_argument("--first_name", type=str, help="First name required for signup.", default="Michael")
    parser.add_argument("--last_name", type=str, help="Surname required for signup.", default="J")
    parser.add_argument("--email", type=str, help="Valid email required for signup.", default="dunksfan85@gmail.com")
    parser.add_argument("--password", type=str, help="Valid password required for signup", default="Passw0rd_1")
    parser.add_argument("--dob", type=str, help="Valid date of birth required for signup, must be of the format dd/mm/yyyy.", default='31/07/1985')
    parser.add_argument("--gender", type=str, help="Gender required for signup. Must be either male or female.", default='male')

    args = parser.parse_args()
    
    account_signup = SignUp(
        fname=args.first_name, 
        lname=args.last_name, 
        email=args.email, 
        pwd=args.password, 
        dob=args.dob, 
        gender=args.gender
    )

    account_signup.signup()