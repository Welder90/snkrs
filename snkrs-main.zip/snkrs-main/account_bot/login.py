import os
from selenium import webdriver
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from config import CHROMEDRIVER_PTH
import time


URL = 'https://nike.com/uk/launch'


def wait_until_visible(driver, xpath=None, class_name=None, el_id=None, duration=10000, frequency=0.01):
    if xpath:
        WebDriverWait(driver, duration, frequency).until(EC.visibility_of_element_located((By.XPATH, xpath)))
    elif class_name:
        WebDriverWait(driver, duration, frequency).until(EC.visibility_of_element_located((By.CLASS_NAME, class_name)))
    elif el_id:
        WebDriverWait(driver, duration, frequency).until(EC.visibility_of_element_located((By.ID, el_id)))

class LogIn():
    def __init__(self, email, pwd, url=URL):
        self.email = email
        self.password = pwd
        self.url = url

    def open_browser(self):
        if os.path.exists(CHROMEDRIVER_PTH):
            self.browser = webdriver.Chrome(executable_path=fr"{CHROMEDRIVER_PTH}")
        else:
            self.browser = webdriver.Chrome('ChromeDriver')

        # set chrome driver settings to make bot less recognisable
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # in addition this will prevent menu from collapsing avoiding additional steps to 
        # which needs to be uncollapsed to navigate to login link
        chrome_options.add_argument("window-size=1400,600")

        self.browser.set_window_size(1920, 1080)
        self.browser.get(self.url)

        time.sleep(2)
    
    def goto_login_page(self):
        # so far xpath seems to be only working approach, this could however break easily
        self.browser.find_element_by_xpath(
            '/html/body/div[2]/div/div/div[1]/div/header/div[1]/section/div/ul/li[1]/button').click()
        
        time.sleep(2)

    def login(self):

        self.open_browser()
        self.goto_login_page()

        # 1. Enter email address
        self.browser\
            .find_element_by_css_selector("input[placeholder='Email address']")\
            .send_keys(self.email)
        
        time.sleep(2)

        # 2. Enter password
        self.browser\
            .find_element_by_css_selector("input[placeholder='Password']")\
            .send_keys(self.password)

        # 3. Sign In
        self.browser\
            .find_element_by_css_selector("input[value='SIGN IN']")\
            .click()

        # 4. Navigate to account details page
        self.browser\
            .find_element_by_class_name('portait-dropdown.portrait-button-css')\
            .click()\
            .send_keys(Keys.DOWN)\
            .send_keys(Keys.RETURN)
        
        #wait_until_visible(driver=self.browser, xpath="//a[@data-path='myAccount:greeting']", duration=5)
        
        # select = Select(
        #     self.browser.find_element_by_class_name(
        #         "portrait-dropdown d-sm-ib va-sm-m"
        #         )
        # )

        # select.select_by_visible_text('Michael J')
        # select.select_by_value('1')

        # self.browser\
        #     .find_element_by_xpath("//*[@id='root']/div/div/div[1]/div/header/div[1]/section/div/ul/li[1]/div/div/button/div/span/span")\
        #     .click()


if __name__ == '__main__':

    account_login = LogIn(
        email='dunksfan85@gmail.com',
        pwd='Passw0rd_1'
    )

    account_login.login()

