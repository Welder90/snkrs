# TODO: move twilio logic into it's own module
# TODO: move app.py outside of sms_forwarder internal package

# === APP IMPORTS ===

from datetime import datetime, timezone, timedelta
from flask import Flask, request, redirect, render_template
from flask_mongoengine import MongoEngine

from twilio.twiml.messaging_response import MessagingResponse
#from sms_forwarder import extract_sms_info, get_message
import time

from twilio.rest import Client
from sms_forwarder.config import TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, VIRTUAL_PHONE_NUM

# === TWILIO CREDENTIALS ===

account_sid = TWILIO_ACCOUNT_SID
auth_token = TWILIO_AUTH_TOKEN
client = Client(account_sid, auth_token)

# === TWILIO HELPER FNS ===

def get_message(sid):
    return client.messages(sid).fetch()

# === FLASK APP INSTANTIATION ===

app = Flask(__name__)

# === MONGODB SETUP & INSTANTIATION ===

# set up mongodb cnxn
app.config['MONGODB_SETTINGS'] = {
    'db': 'snkrs',
    'host': 'localhost',
    'port': 27017
}

db = MongoEngine()
db.init_app(app)

# === MONGODB DATA MODEL SETUP ===
class Users(db.Document):
    name = db.StringField()
    email = db.StringField()
    password = db.StringField()
    first_name = db.StringField()
    last_name = db.StringField()
    dob = db.StringField()
    gender = db.StringField()
    pub_date = db.DateTimeField(datetime.now)

# === USER ADMIN/RECORDS ENDPOINT ===

@app.route('/')
def query_records():
    users = Users.objects.all()
    return render_template('useradmin.html', users=users)

# === SMS FORWARDING ENDPOINT ===

@app.route('/sms', methods=['GET','POST'])
def sms():
    """ Send a dynamic replay to an incoming text message."""
    for k, v in request.values.items():
        print(f'key: {k}; value: {v}\n')

    # Get the message the user sent our Twilio number
    body = request.values.get('Body', None)
    from_ = request.values.get('From', None)
    to = request.values.get('To', None)
    sid = request.values.get('MessageSid', None)

    # Start our TwiML response
    resp = MessagingResponse()
    
    time_sent = str(get_message(sid).date_sent)
    
    print(f'SID: {sid}')
    print(f'SID type: {type(sid)}')
    print(f'TIME SENT: {time_sent}')
    
    time_received = str(datetime.now())

    # Add a message
    resp.message(f"""
    \n\nYour message has been received by the SNKRS application. Details of message:
    - Sent from: {from_}
    - Sent to: {to}
    - Body: '{body}'
    - Time received: {time_received}
    """)    

    return str(resp)


if __name__ == '__main__':
    app.run(debug=True)