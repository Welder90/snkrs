import os
from datetime import datetime
from twilio.rest import Client
from config import TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, VIRTUAL_PHONE_NUM

account_sid = TWILIO_ACCOUNT_SID
auth_token = TWILIO_AUTH_TOKEN
client = Client(account_sid, auth_token)

def list_all_message_sids(limit=20):
    messages = client.messages.list(limit=limit)
    return [record.sid for record in messages]

def filter_messages(date_sent=None, from_=None, to=VIRTUAL_PHONE_NUM, limit=20):
    messages = client.messages.list(
        date_sent = date_sent,
        from_=from_,
        to=to,
        limit=limit
    )
    return [record.sid for record in messages]

def fetch_sms():
    return client.messages.stream()

def get_last_sms():
    sms = fetch_sms()
    message = next(sms)
    
def extract_sms_info():
    message = get_last_sms()
    return message.body, message.from_, message.to, message.date_sent   

def get_message(sid):
    return client.messages(sid).fetch()